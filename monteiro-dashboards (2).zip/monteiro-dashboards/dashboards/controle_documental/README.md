# Dashboard — Controle Documental (Filiais)

Acompanhamento da situação documental dos negócios públicos por filial do escritório Monteiro e Monteiro.

---

## Contexto

O escritório possui filiais em diversas cidades (Recife, Brasília, Fortaleza, Rio de Janeiro, Salvador, São Luís, São Paulo, Belém). Cada filial registra manualmente em uma aba do Google Sheets o andamento dos negócios: contratos, procurações, kits e publicações.

Este dashboard consolida esses dados para dar visibilidade à diretoria sobre a situação documental de cada negócio.

---

## Fonte de Dados

| Planilha | Tipo | Abas / Registros |
|----------|------|-----------------|
| Acompanhamento de Filiais | Fato | 8 abas (~5.900 linhas) |
| d_materia | Dimensão | 35 registros |
| d_estado | Dimensão | 27 registros |
| d_filial | Dimensão | 8 registros |
| d_municipio | Dimensão | 5.573 registros |

---

## Pipeline

```
Google Sheets (input) → Diagnóstico → Saneamento → ETL → BigQuery → Looker Studio
```

### Etapas

| Pasta | Descrição | Status |
|-------|-----------|--------|
| `01_diagnostico/` | Análise de qualidade da base | Em andamento |
| `02_saneamento/` | Correção e limpeza dos dados | Pendente |
| `03_etl/` | Extração, transformação e carga no BigQuery | Pendente |
| `04_looker/` | Configuração do dashboard no Looker Studio | Pendente |

---

## Problemas Conhecidos (Diagnóstico)

| # | Problema | Impacto | Severidade |
|---|----------|---------|------------|
| 1 | Aba Matriz com linha em branco no topo | 1.497 linhas ausentes | Crítica |
| 2 | Valores financeiros com "R$" | 944 valores nulos (22%) | Crítica |
| 3 | "OK" na coluna Data Publicação (Matriz) | 254 datas inválidas | Alta |
| 4 | Duplicatas entre filiais | 256 linhas | Alta |
| 5 | Campos obrigatórios vazios | 128 linhas descartadas | Alta |
| 6 | Matérias sem match na dimensão | 95 linhas perdidas | Alta |
| 7 | Municípios sem match na dimensão | 51 linhas perdidas | Média |
| 8 | Datas com formato inválido | 72 datas nulas | Média |
| 9 | Filial DF com header diferente | Coluna de data ignorada | Média |
| 10 | Filial SC desativada | 47 linhas ignoradas | Baixa |

---

## Como Executar

```bash
# A partir da raiz do repositório
cd dashboards/controle_documental

# Rodar diagnóstico completo
python 01_diagnostico/run_all.py

# Rodar saneamento (quando disponível)
python 02_saneamento/run_all.py

# Rodar ETL (quando disponível)
python 03_etl/run_pipeline.py
```
