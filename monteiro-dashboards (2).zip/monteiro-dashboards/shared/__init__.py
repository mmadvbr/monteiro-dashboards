"""Módulos compartilhados entre dashboards."""
